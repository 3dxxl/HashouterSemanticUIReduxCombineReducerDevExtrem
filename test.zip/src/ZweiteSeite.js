import React, { Component } from 'react'

export class ZweiteSeite extends Component {
  render() {
    return (
      <div>
        Das ist die ZweiteSeite
      </div>
    )
  }
}

export default ZweiteSeite;
