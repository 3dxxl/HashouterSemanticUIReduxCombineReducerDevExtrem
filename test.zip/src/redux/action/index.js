//das geht noch nicht

import {DASISTEINEACTION} from './Types';

export const DASISTEINEACTIONS = () => async (dispatch) => {



    dispatch({

        type:DASISTEINEACTION,
        payload:'blue'

    });



};