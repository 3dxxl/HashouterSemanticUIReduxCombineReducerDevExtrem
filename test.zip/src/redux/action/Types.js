import {store} from '.././MeinStore';


export const DASISTEINEACTION = { 
	nameOffTheAction: () => {
		return {type: "DASISTEINEACTION"};
	}
	
	
}




function increment() {
    return {
      type: "DASISTEINEACTION"
    };
  }
  
  function incrementAsync() {
    return dispatch => {
        alert("Hallo");
      setTimeout(() => {
        // Yay! Can invoke sync or async actions with `dispatch`
        dispatch(increment());
      }, 1000);
    };
  }